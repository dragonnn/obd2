fn main() {
    /*let dbc_path = "./docs/DBC/opendbc/hyundai_kia_generic.dbc";
    let dbc_file = std::fs::read(dbc_path).unwrap();
    println!("cargo:rerun-if-changed={}", dbc_path);

    let mut out = std::io::BufWriter::new(std::fs::File::create("src/obd2/dbc.rs").unwrap());
    dbc_codegen::codegen("hyundai_kia_generic.dbc", &dbc_file, &mut out, true).unwrap();*/
}

pub use crate::tasks::{
    lcd::{LcdEvent, EVENTS as LCD_EVENTS},
    obd2::Obd2Event,
    state::{KiaEvent, EVENTS as KIA_EVENTS},
};

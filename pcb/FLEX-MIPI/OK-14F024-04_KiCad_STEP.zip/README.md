# OCN OK-14F024-04 KiCad library

This is the 24-contact, 0.40 mm-pitch board-side socket that mates with the
`OK-14GM024-04` header fitted to the AM319M262928ZS AMOLED panel flex.

## Contents

- `OK-14F024-04.kicad_sym` — KiCad symbol library (24 electrical pins)
- `OK-14F024-04.pretty/` — SMD footprint
- `OK-14F024-04.3dshapes/CONN-SMD_24P-P0.40_OK-14F024-04.step` — detailed STEP model

The footprint originates from JLC/LCSC part `C9900019201` and was checked
against the OCN series drawing: 24 contacts, 0.40 mm pitch, 7.30 mm overall
length, 2.50 mm body width and 0.80 mm mounting height. The four retention
lands are intentionally unnumbered mechanical pads.

The detailed STEP model was supplied with the exact EasyEDA/JLC component and
its 7.30 x 2.50 mm envelope was checked against the manufacturer drawing.

Place `OK-14F024-04.pretty` and `OK-14F024-04.3dshapes` in the KiCad project
root so the footprint's `${KIPRJMOD}` 3D-model path resolves automatically.

Before ordering a PCB, confirm pad 1 against the panel drawing and the actual
panel-flex orientation. This is a bottom-contact board-to-board connector, so
mirroring it will not produce a usable mechanical mate.

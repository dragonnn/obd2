# MinewSemi ME54BS01 / ME54BS12 KiCad library

Native KiCad symbol + footprint library for the nRF54L15 variants.

## Included
- `MinewSemi_nRF54.kicad_sym`
- `MinewSemi_nRF54.pretty/ME54BS01_nRF54L15.kicad_mod`
- `MinewSemi_nRF54.pretty/ME54BS12_nRF54L15.kicad_mod`
- `MinewSemi_nRF54.3dshapes/ME54BS01.step`
- `MinewSemi_nRF54.3dshapes/ME54BS12.step`

## Sources / geometry
Footprints were reconstructed from MinewSemi's official mechanical drawings and pin-definition tables for the nRF54L15 K (development) variants.

ME54BS01 envelope: 17.4 x 23.2 x 2.0 mm. 28 castellated edge pads; edge pitch 1.2 mm.
ME54BS12 envelope: 12.0 x 15.8 x 2.0 mm. 18 castellated edge pads at 1.27 mm pitch plus 21 underside pads arranged on the manufacturer's 1.5 x 1.8 mm grid.

The `User.1` layer contains the antenna outline and a second rectangle showing the manufacturer's recommended 4 mm metal/component clearance. This is a visual marker, not an enforced KiCad rule area.

## Important note about STEP files
No manufacturer-provided STEP model was found in MinewSemi's public download center. The included STEP files are simplified, dimensionally accurate envelope models generated from the official module dimensions. They are intended for PCB fit / enclosure checking, not component-level mechanical detail.

## Installation
1. Keep the three library items/folders together in your KiCad project directory.
2. Add `MinewSemi_nRF54.kicad_sym` as a project-specific Symbol Library.
3. Add `MinewSemi_nRF54.pretty` as a project-specific Footprint Library with nickname `MinewSemi_nRF54`.
4. The footprints reference `${KIPRJMOD}/MinewSemi_nRF54.3dshapes/*.step`, so the 3D models load automatically if the folders remain at project root.

## Design warning
Before production, compare the footprint against the exact MinewSemi datasheet revision supplied with your module. MinewSemi states a default mechanical tolerance of +/-0.15 mm. The underside-pad X origin on ME54BS12 is centered from the mechanical grid; verify against your fabrication drawing if your assembler requires a manufacturer-released land pattern.
